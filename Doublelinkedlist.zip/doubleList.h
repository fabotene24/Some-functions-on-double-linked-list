
#pragma once
#include <iostream>
using namespace std;

//structure definition
template <class T>
struct node
{
	T info;
	node<T>* next;
	node<T>* previous;

};



template <class T>
class doubleList
{
protected:
	int count;
	node< T>* first;
	node <T>* current; //Pointer to iterate 
	node <T>* last;  //Pointer to the last node

public:

	//Default constructor
	doubleList();

	//Copy constructor
	doubleList(const doubleList<T>&);


	//Copy function
	void copy(const doubleList<T>&);

	//Destructor
	~doubleList();

	//Check whether the doubly list is empty
	bool isEmpty();

	//Print the doubly list forward
	void print();

	//Print the doubly list backward
	void printBackward();

	//Return the length of the list
	int length();

	//Insert item on the list
	void insert(T);

	//Delete an item on the list
	void deleteItem(T);

	//Empty the list
	void emptyList();

	//Find for the item
	bool searchItem(T);

  //selection sort
  //void selection();

};
