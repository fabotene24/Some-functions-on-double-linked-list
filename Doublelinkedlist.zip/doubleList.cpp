
#include "doubleList.h"

//function to print the item backward

template<class T>
void doubleList<T> :: printBackward()
{
	cout << endl;
	if (first != nullptr)
	{
		node<T>* p = last;
		cout << "The descending order is: ";
		while (p != nullptr)
		{
			cout << p->info << " <==>  ";
			p = p->previous;
		}
		cout<<"NULL";
	}
	else cout << "[Warning] - The List is empty" << endl;
}

template<class T>
doubleList<T>::doubleList(const doubleList<T>& other)
{
	first = nullptr;
	copy(other);
}

//copy constructor
template<class T>
void doubleList<T>::copy(const doubleList<T>& other)
{
	//Case 1: Empty list
	if (other.first == nullptr)
	{
		first = nullptr;
	}
	//Case 2: non-empty list
	else
	{
		//Copy the first node
		emptyList();
		first = new node<T>;
		first->info = other.first->info;
		first->previous = other.first->previous;
		node<T>* p = other.first->next;
		node<T>* s = first;
		while (p != nullptr)
		{
			s->next = new node<T>;
			s->next->info = p->info;
			s->previous = p->previous->previous;
			p = p->next;
			s = s->next;
		}
		s->previous = other.last->previous;
		s->next = nullptr;
	}
}


//function to search an item inside the list
template<class T>
bool doubleList<T>::searchItem(T item)
{
	bool found = false;
	if (first == nullptr)
	{
		cout << "Warning - The list is empty" << endl;
	}
	else
	{
		current = first;
		while (current != nullptr && !found)
		{
			if (current->info == item)
			{
				found = true;
				cout << "Your item has been found in the list!" << endl;
			}
			current = current->next;
		}
	}
	return found;
}


//Function to delete the element of the list item by item
template<class T>
void doubleList<T>::emptyList()
{
	if (first == nullptr)
	{
		cout << "[Warning] - The List is already empty" << endl;
	}
	else
	{
		node<T>* p;
		//Use the last pointer
		while (first != nullptr)
		{
			p = last;
			if (last->previous != nullptr)
			{
				last = last->previous;
				last->next = nullptr;
				delete p;

			}
			//Last component to remove
			else
			{
				delete p;
				first = nullptr;
				last = first;
			}
		}
		count = 0;
		cout << "You have sucessfully empty the list" << endl;
	}
}


//Delete member function
template<class T>
void doubleList<T>::deleteItem(T deleteItem)
{
	//Assign the pointer to the first position
	bool found = false;
	current = first;

	//Case 1: empty list
	if (first == nullptr)
	{
		cout << "[Warning] Deletion failed - List is empty" << endl;
	}
	else
	{
		//Case 2: the only node
		if (first->info == deleteItem)
		{
			node<T>* p = first;
			first = p->next;
			delete p;
			count--;
			cout << "You have sucessfully deleted the item" << endl;
		}
		else
		{
			while (current->next != nullptr && current->info != deleteItem && !found)
			{
				current = current->next;
				//Case 3: in the middle of the list
				if (current->info == deleteItem && current->next != nullptr)
				{
					node<T>* p = current;
					p->previous->next = p->next;
					p->next->previous = p->previous;
					count--;
					delete p;
					found = true;
					cout << "You have sucessfully removed the item" << endl;
				}
			}
			//Case 4 - end of the list
			if (current->info == deleteItem)
			{
				node<T>* p = current;
				p->previous->next = nullptr;
				delete p;
				cout << "You have sucessfully removed the item" << endl;

			}
			//Case 5 - not found the number
			if (current->next == nullptr)
			{
				cout << "The item entered has not been found" << endl;
			}
		}
	}

}



//Insert member function
template <class T>
void doubleList<T>::insert(T insertItem)
{
	//Case 1 = list is empty
	if (first == nullptr)
	{
		node<T>* p;
		p = new node<T>;
		p->next = first;  //NULL values
		p->previous = first;  // Null values
		p->info = insertItem;
		first = p;
		last = p;
		count++;

	}
	else  // For non-empty cases
	{
		node<T>* followingNode;
		current = first;
		bool found = false;  //Flag for find correct position
		while ((!found) && current != nullptr)  // If its not found and not the last node it will continue
		{
			//for before first node
			if (first->info >= insertItem)
			{
				node<T>* p;
				p = new node<T>;

				p->info = insertItem;
				p->previous = first->previous;
				p->next = first;
				first->previous = p;
				first = p;
				found = true;

				count++;

			}
			else
			{
				//Case for end of the list
				if ((insertItem >= current->info) && (current->next == nullptr))
				{
					node<T>* p = new node<T>;
					p->info = insertItem;
					p->next = nullptr;
					p->previous = current;
					current->next = p;
					found = true;
					count++;
					last = p;
				}
				//Add the last case here, middle on the list
				if (((current->info < insertItem) && (current->next->info > insertItem)) && !(current->next == nullptr))
				{
					followingNode = current->next;
					node<T>* p;
					p = new node<T>;
					p->info = insertItem;
					p->next = current->next; //point two
					p->previous = current;// point one
					current->next = p;
					followingNode->previous = p;
					found = true;
					count++;


				}
				current = current->next;
			}
		}
	}

}


//Print the doubly list
template <class T>
void doubleList<T>::print()
{
	if (isEmpty())
	{
		cout << "The list is empty" << endl;
	}
	else
	{
		//Assuming the doubly linked list is sorted
		current = first;
		cout << endl;
		cout << "The acending order of the list is: ";
		while (current != nullptr)
		{
			cout << current->info << " <==> ";
			current = current->next;
		}
    cout<<"NULL";
	}
	
}

//Default constructor
template<class T>
doubleList<T>::doubleList()
{
	first = nullptr;
	last = nullptr;
	count = 0;
}



//Destructor
template<class T>
doubleList<T>::~doubleList()
{
  node <T> * p ;
 while (first != nullptr)
 { 
   p = first;
   first = first->next;
   p = p->next;
   delete p;
 }
 cout<<"You have succefully called the destructor - The list is empty"<<endl;
  
}



//IsEmpty 
template <class T>
bool doubleList<T>::isEmpty()
{
	return (first == nullptr);
}


//Length 
template <class T>
int doubleList<T>::length()
{
	return count;
}

/*//selection sort
template <class T>
void doubleList<T>::selection(){
  if(first == nullptr)
    cout<<"Your list is empty"<<endl;
  else {
    node <T> *p = first;
    node <T> *s = first;
    int min;
    while( p != nullptr)
    {
      min = p->info;
      p = p->next;
      while( s!= nullptr)
      {
        s = s->next;
        if (s->info < p->info)
          {
            min = s->info;
            int d = p -> info;
            p->info = s->info;
            s->info = d;
          }
      }

    }
  }
   
}*/


