#include <stdlib.h>
#include "doubleList.h"
#include "doubleList.cpp" 
#include <string>  

void Menu();
int endProgram();

  
int main()
{

		int ans;
		int res;
		bool end = false;
    do{
		cout << "------------ Menu of the Program ---------#" << endl;
    cout << "#     !!!!!!!  WELCOME  !!!!!!!!!!        #" 
    <<endl;
		cout << "#      Choose any of the following        #" << endl;
		cout << "#    option to test some functionalities  #" << endl;
		cout << "#    of the sorted doubly linked list     #" << endl;
		cout << "#-----------------------------------------#" << endl;
 
		cout << "Press 1 to continue the program" << endl;
		cin >> ans;

		cout << "Here is the Menu, choose any functionnalities that you want to test" << endl;
    }while (ans != 1);
    
			doubleList<int> list;

			int item;
			while (!(end))
			{
		
				//Display option list to the user
				cout << endl;
				Menu();  
				cin >> res;
				switch (res)
				{
				case 1:
					cout << "Enter a value of item to insert" << endl;
					cin >> item;
					list.insert(item);
					break;

				case 2:
					cout << "Enter a value of item to delete" << endl;
					cin >> item;
					list.deleteItem(item);
					break;

				case 3:
					cout << "Enter a value of item to find" << endl;
					cin >> item;
					if (list.searchItem(item))
						continue;
					else
						cout<< "Review your selection and choose another one" << endl;
					break;

				case 4:
					list.emptyList();
					break;

				case 5:
					if (list.isEmpty())
						cout << "The List is empty" << endl;
					else
						cout << "The List is not empty" << endl;
					break;

				case 6:
					int length;
					length =list.length();
					cout << "The length of the list is " << length << " items" << endl;
					break;

				case 7:
					list.print();
					break;

				case 8:
					list.printBackward();
					break;

          case 9:
					list.~doubleList();
					break;

        

  
				case 10:
         endProgram();
         break;
          default:
          cout<<"Your choice does not exit! Reviews it."<<endl;
          
         	
				}

			}
      
    }



void Menu()
{
	//Add option to identify data type first
	cout << "################## Options ##################" << endl;
  cout << "# (1) - Insert an item                      #" << endl;
 cout << "# (2) - Delete an item                      #" << endl;
 cout << "# (3) - Search an Item.                     #" << endl;
	cout << "# (4) - Empty the list                      #" << endl;
 cout << "# (5) - Check if the list is empty          #" << endl;
	cout << "# (6) - Return the length of the list       #" << endl;
	cout << "# (7) - Print the list in ascending order   #" << endl;
	cout << "# (8) - Print the list in descending order  #" << endl;
  cout << "# (9) - Call the destructor.                #" << endl;
	cout << "# (10)- Sort the list with selection sort.  #" << endl;
  cout << "# (11) - End the program.                   #" << endl;
	cout << "#############################################" << endl;
	cout << "Enter a option: ";
}
int endProgram(){
  cout<<"You have choose to exit the program"<<endl;
   exit(0);
}

